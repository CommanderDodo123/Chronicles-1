# Chronicle PWA

Chronicle is now a Progressive Web App (PWA).

## Install on Android
1. Host this folder from a web server over HTTPS (GitHub Pages, Netlify, Vercel, etc.).
2. Open the HTTPS site in Chrome on Android.
3. Use Chrome's menu and choose **Install app** (or **Add to Home screen**).
4. Launch Chronicle from the new home-screen icon. It opens in standalone full-screen app mode.

A PWA cannot be installed from a `file://` URL. The service worker requires HTTPS (localhost is the exception for development).

## Local development
Run a simple local server from this folder, for example:
`python -m http.server 8000`
Then visit `http://localhost:8000`.

## Features
- Installable home-screen app
- Roman marble/pillar visual identity
- Standalone portrait mobile interface
- Offline caching after first load
- Existing Chronicle progress remains stored in the browser
