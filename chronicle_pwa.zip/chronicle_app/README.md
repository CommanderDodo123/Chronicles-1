# Chronicle — Functional Prototype

A dependency-free, browser-based educational game inspired by the approved Roman marble / pillar UI.

## Included
- History, Philosophy, Maths, Science and Religion courses
- Progressive lesson paths with locking/unlocking
- Lesson reading screens
- Functional quizzes with feedback
- XP, gems, streaks and accuracy tracking
- Completion rewards and achievements
- League leaderboard
- Profile and editable scholar name
- LocalStorage persistence
- Responsive desktop/mobile layout
- Roman marble, travertine, bronze and deep-red visual system

## Run
Open `index.html` in a modern browser. No server or build step is required.

## Data
Progress is stored locally in the browser under `chronicleState`. Use Profile → Reset local progress to clear it.

## Next production steps
- Add an authenticated backend/database
- Add a larger content/question bank
- Add accounts and cloud sync
- Add audio, accessibility improvements and richer lesson media
- Add teacher/admin content tools
- Add real weekly league calculations
